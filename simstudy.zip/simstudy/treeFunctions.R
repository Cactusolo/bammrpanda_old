require(ouch)
require(aakmisc)

options(stringsAsFactors=FALSE)

## function to insert regime-shift nodes
## shifts are Poisson distributed along each branch
insertPoissonEpochs <- function (tree, wait.time) {
  if (!is(tree,'ouchtree'))
    stop(sQuote("tree")," must be an ouchtree")
  tr <- as(tree,"data.frame")
  tr$nodes <- as.character(tr$nodes)
  tr$labels <- as.character(tr$labels)
  tr$ancestors <- as.character(tr$ancestors)
  rownames(tr) <- tr$nodes
  ## label tips as tips (this overwrites species names)
  tr[tree@term,"labels"] <- "TIP"
  ## time of ancestor node:
  tr$t1 <- tr[tr$ancestors,"times"]
  tr$t1 <- with(tr,ifelse(is.na(t1),0,t1))
  ## number of shiftpoints on a branch is Poisson:
  tr$nshift <- with(
                     tr,
                     rpois(
                           n=length(times),
                           lambda=(times-t1)/wait.time
                           )
                     )
  ## choose the shiftpoints:
  ## (conditional on their number, they are uniform)
  sp <- ldply(
              which(tr$nshift>0),
              function (k) {
                ## names of nodes
                nn <- sprintf(
                              "sw%s-%d",
                              tr$nodes[k],
                              seq_len(tr$nshift[k])
                              )
                ## necessary ingredients:
                data.frame(
                           nodes=nn,
                           ancestors=c(
                             tr$anc[k],
                             head(nn,-1)
                             ),
                           times=sort(
                             runif(
                                   n=tr$nshift[k],
                                   max=tr$times[k],
                                   min=tr$t1[k]
                                   )
                             ),
                           labels="SHIFT"
                           )
              }
              )
  ## insert the new nodes:
  labs <- sprintf("sw%s-%d",tr$nodes,tr$nshift)
  tr[tr$nshift>0,'ancestors'] <- labs[tr$nshift>0]
  tr <- rbind(tr[c("nodes","ancestors","times","labels")],sp)
  with(tr,ouchtree(nodes=nodes,ancestors=ancestors,times=times,labels=labels))
}

## paint regimes on a tree so that they shift at chosen points
## assumes that the 'labels' slot indicates where the shifts are.
## We condition on there being at least one tip in each regime,
## using the rejection method to accomplish this.
paintTree <- function (tree, nregimes) {
  tr <- as(tree,"data.frame")
  lins <- tree@lineages[tree@term]
  sp <- which(tr$labels=="SHIFT")
  if (length(sp)<1) stop("no shift points on this tree")
  reject <- TRUE
  if (nregimes > tree@nterm) {
    stop("more than ",tree@nterm," tip regimes is not possible")
  }
  while (reject) {
    reg <- integer(tree@nnodes)
    delta <- integer(tree@nnodes)
    delta[sp] <- sample.int(n=nregimes-1,size=length(sp),replace=TRUE)
    cur <- sample.int(n=nregimes,size=1)
    for (lin in lins) {
      for (n in rev(lin)) {
        if (reg[n]==0) {
          reg[n] <- cur
          cur <- cur+delta[n]
        } else {
          cur <- reg[n]
        }
      }
    }
    reg <- (reg%%nregimes)+1
    reject <- any(tabulate(reg[tree@term],nbins=nregimes)==0)
  }
  setNames(LETTERS[reg],tree@nodes)
}

## randomly permute the ordering of the tips,
## conditional on there being at least one tip in each regime.
## In this, we first randomly choose one tip from each regime,
## then the rest of the tips, in random order.
permuteTips <- function (nodes, labels, regimes) {
  tips <- which(labels=="TIP")
  tipreg <- regimes[tips]
  first <- sapply(
                  unique(regimes),
                  function (n) {
                    k <- which(tipreg==n)
                    k[sample.int(n=length(k),size=1)]
                  }
                  )
  tips1 <- tips[first]
  tips2 <- tips[-first]
  tips2 <- tips2[order(runif(n=length(tips2)))]
  nodes[c(tips1,tips2)]
}

## pick out a subtree by the tips
subtree <- function (tree, tips) {
  w <- which(as.character(tree@nodes)%in%tips)
  n <- sort(unique(do.call(c,tree@lineages[w])))
  tr <- as(tree,"data.frame")
  with(tr[n,],ouchtree(nodes,ancestors,times,labels))
}

## compute various metrics
treeMetrics <- function (tr, perm, size) {
  tree <- with(tr,ouchtree(nodes,ancestors,times,labels))
  tips <- head(perm$nodes,size)
  tree <- subtree(tree,tips)
  sbtr <- as(tree,"data.frame")
  sbtr$ancestors <- as.character(sbtr$ancestors)
  sbtr$nodes <- as.character(sbtr$nodes)
  sbtr$labels <- as.character(sbtr$labels)
  sbtr$regimes <- tr[tr$nodes%in%sbtr$nodes,"regimes"]
  rownames(sbtr) <- sbtr$nodes
  ## compute branch-lengths
  sbtr$t1 <- sbtr[sbtr$ancestors,"times"]
  sbtr$t1 <- ifelse(is.na(sbtr$t1),0,sbtr$t1)
  sbtr$bl <- with(sbtr,times-t1)
  ## counts of true nodes along each lineage
  lins <- vapply(
                 tree@lineages[tree@term],
                 function (lin) {
                   ndesc <- sapply(
                                   lin,
                                   function (n) {
                                     sum(tree@ancestors==tree@nodes[n],
                                         na.rm=TRUE)
                                   }
                                   )
                   sum(ndesc>1)
                 },
                 integer(1)
                 )
  stats <- ddply(
                 sbtr,
                 ~regimes,
                 summarize,
                 bl=sum(bl),
                 tips=sum(labels=="TIP")
                 )
  ## number of regimes:
  nreg <- length(unique(sbtr$regimes))
  ## expectation of Sackin index under coalescent model
  ## (Kirkpatrick & Slatkin, 1993):
  esack <- 2*size*sum(1/seq.int(from=2,to=size))
  ## Shannon entropy:
  shannon <- function (x) -sum((x/sum(x))*log(x/sum(x)))
  ## four statistics are measured:
  ## be = branch evenness (Shannon entropy of lineage-time in each regime)
  ## te = tip evenness (Shannon entropy of tip regime distribution)
  ## imb = Sackin index of imbalance
  ##     (mean number of true nodes between tip and root minus expected number)
  summarize(
            stats,
            be=shannon(bl)/log(nreg),
            te=shannon(tips)/log(nreg),
            imb=(sum(lins)-esack)/size,
            nA=tips[1],
            nB=tips[2],
            nC=tips[3]
            )
}
