## 4/14080000 IDs were problematic: parameters could not be estimated to computational singularity
## associated with the particular datasets generated
## for these 4, we use new random seeds

require(doMC)
require(foreach)
require(iterators)
require(aakmisc)
require(ouch)

projname <- "ouchsim"

username <- Sys.info()["user"]
script <- Sys.getenv("SCRIPT")
ncpus <- as.integer(Sys.getenv("NCPU"))
jobid <- Sys.getenv("JOBID")
results.file <- paste0(script,"-final-res.rda")

options(stringsAsFactors=FALSE,aakmisc.dbname=projname)

source("fitFunctions.R")

paramsets <- readRDS("paramDesign.rda")
trees <- readRDS("treeDesign.rda")
perms <- readRDS("subtreeDesign.rda")
seeds <- readRDS("datasetDesign.rda")

registerDoMC(ncpus)

design <- expand.grid(
                      painting=unique(perms$painting),
                      permutation=unique(perms$permutation),
                      paramset=seq_len(nrow(paramsets)),
                      seed=seeds
                      )
design$id <- seq_len(nrow(design))

startTunnel()
fin <- getQuery("select id from fits1")
stopTunnel(tun)

design <- subset(design,!id%in%fin$id)

## replace problematic seeds with 4 random.org seeds
design$seed <- c(2101675956L,873771466L,1852372842L,976753521L)

RNGkind("L'Ecuyer-CMRG")

tic <- Sys.time()

res <- foreach (job=iter(design,by='row'),
                .inorder=FALSE,
                .errorhandling='pass',
                .combine=rbind,
                .multicombine=TRUE,
                .noexport=c("trees","perms","subtree","paramsets",
                  "fitAll","fitBM","fitNP","fitOU1","fitOU2ab","fitOU2bc","fitOU3",
                  "gendata"),
                .verbose=FALSE
                ) %dopar%
{
  dat <- gendata(
                 tr=subset(
                   trees,
                   painting==job$painting
                   ),
                 perm=subset(
                   perms,
                   painting==job$painting &
                   permutation==job$permutation
                   ),
                 seed=job$seed,
                 params=paramsets[job$paramset,]
                 )
  fit <- fitAll(dat)
  data.frame(job,as.list(fit))
}

toc <- Sys.time()

saveRDS(res,file=results.file)

q(save='no')
