require(doMC)
require(foreach)
require(iterators)
require(aakmisc)
require(ouch)

projname <- "ouchsim"

chunksize <- 40000

username <- Sys.info()["user"]
script <- Sys.getenv("SCRIPT")
arrayid <- as.integer(Sys.getenv("ARRAYID"))
ncpus <- as.integer(Sys.getenv("NCPU"))
jobid <- Sys.getenv("JOBID")
results.file <- paste0(script,"-%09d-res.rda")

options(stringsAsFactors=FALSE,aakmisc.dbname=projname)

source("fitFunctions.R")

paramsets <- readRDS("paramDesign.rda")
trees <- readRDS("treeDesign.rda")
perms <- readRDS("subtreeDesign.rda")
seeds <- readRDS("datasetDesign.rda")

registerDoMC(ncpus)

design <- expand.grid(
                      painting=unique(perms$painting),
                      permutation=unique(perms$permutation),
                      paramset=seq_len(nrow(paramsets)),
                      seed=seeds
                      )
design$id <- seq_len(nrow(design))
chunk <- ((design$id-1) %/% chunksize) + 1
design <- design[chunk==arrayid,]

RNGkind("L'Ecuyer-CMRG")

tic <- Sys.time()

res <- foreach (job=iter(design,by='row'),
                .inorder=FALSE,
                .errorhandling='remove',
                .combine=rbind,
                .multicombine=TRUE,
                .noexport=c("trees","perms","subtree","paramsets",
                  "fitAll","fitBM","fitNP","fitOU1","fitOU2ab","fitOU2bc","fitOU3",
                  "gendata"),
                .verbose=FALSE
                ) %dopar%
{
  dat <- gendata(
                 tr=subset(
                   trees,
                   painting==job$painting
                   ),
                 perm=subset(
                   perms,
                   painting==job$painting &
                   permutation==job$permutation
                   ),
                 seed=job$seed,
                 params=paramsets[job$paramset,]
                 )
  fit <- fitAll(dat)
  data.frame(job,as.list(fit))
}

toc <- Sys.time()

saveRDS(res,file=sprintf(results.file,arrayid*chunksize))

cat("jobs=",nrow(res),"ncpus=",ncpus,
    "chunksize=", chunksize,
    "etime=",as.numeric(toc-tic,units='secs'),
    "date=",as.character(toc),"\n")

q(save='no')
