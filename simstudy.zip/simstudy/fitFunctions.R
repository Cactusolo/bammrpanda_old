require(ouch)
require(plyr)
require(reshape2)

options(stringsAsFactors=FALSE)

source("simstudy/treeFunctions.R")

gendata <- function (tr, perm, seed, params) {
  rownames(tr) <- tr$nodes
  tr$regimes <- factor(tr$regimes)
  ## set up ouchtree:
  tree <- with(tr,ouchtree(nodes,ancestors,times))
  ## dummy data:
  tr$data <- 0
  ## compute values of alpha, sigma from eta, phi
  dtheta <- 1
  alpha <- params$eta/tree@depth
  sigma <- sqrt(2*alpha)*dtheta/params$phi
  ## minimum interval between optima
  ## fix true theta.
  ## for OU(3), theta = c(-1,0,1)
  nreg <- length(levels(tr$regimes))
  theta <- dtheta*seq(
                      from=-((nreg-1)%/%2),
                      by=1,
                      length=nreg
                      )
  ## set up hansentree for generating data
  h <- hansen(
              data=tr["data"],
              tree=tree,
              regimes=tr["regimes"],
              sqrt.alpha=sqrt(alpha),
              sigma=sigma,
              fit=FALSE
              )
  ## fix theta at true values:
  h@theta$data[] <- theta
  ## simulate data:
  tr$data <- simulate(h,nsim=1,seed=seed)[[1]][[1]]
  ## select subtree:
  h <- subtree(h,head(perm$nodes,params$size))
  tr <- subset(tr,nodes%in%h@nodes)
  ## regenerate hansentree for subtree
  h <- hansen(
              data=tr["data"],
              tree=h,
              regimes=tr["regimes"],
              sqrt.alpha=sqrt(alpha),
              sigma=sigma,
              fit=FALSE
              )
  h@theta$data[] <- theta
  h
}

## fit OU3 model given a hansentree with data
## (this assumes dtheta = 1)
fitOU3 <- function (htree) {
  fit <- update(htree)
  fit <- update(fit,method="subplex")
  s <- summary(fit)
  dtheta <- min(diff(sort(s$optima$data)))
  c(
    aic.c=if (s$conv.code<0) NA else s$aic.c,
    est=c(
      eta=s$alpha[1,1]*htree@depth,
      phi=sqrt(2*s$alpha[1,1])*dtheta/sqrt(s$sigma.squared[1,1]),
      theta=s$optima$data
      )
    )
}

## fit Brownian motion (BM) model given a hansentree with data
fitBM <- function (htree) {
  fit <- brown(data=htree@data,tree=htree)
  c(aic.c=summary(fit)$aic.c)
}

## fit OU1 model
fitOU1 <- function (htree) {
  reg <- htree@regimes[[1]]
  reg[] <- "A"
  fit <- update(htree,regimes=reg)
  fit <- update(fit,method="subplex")
  s <- summary(fit)
  c(aic.c=if (s$conv.code<0) NA else s$aic.c)
}

## fit OU2 with regime C collapsed into B
fitOU2ab <- function (htree) {
  reg <- htree@regimes[[1]]
  reg[reg=="C"] <- "B"
  fit <- update(htree,regimes=reg)
  fit <- update(fit,method="subplex")
  s <- summary(fit)
  c(aic.c=if (s$conv.code<0) NA else s$aic.c)
}

## fit OU2 with regime A collapsed into B
fitOU2bc <- function (htree) {
  reg <- htree@regimes[[1]]
  reg[reg=="A"] <- "B"
  fit <- update(htree,regimes=reg)
  fit <- update(fit,method="subplex")
  s <- summary(fit)
  c(aic.c=if (s$conv.code<0) NA else s$aic.c)
}

## fit non-phylogenetic (NP) model
fitNP <- function (htree) {
  dat <- subset(as(htree,'data.frame'),!is.na(data))
  fit <- lm(data~regimes-1,data=dat)
  df <- length(levels(dat$regimes))
  n <- nrow(dat)
  c(aic.c=AIC(fit)+2*df*(df+1)/(n-df-1))
}

fitAll <- function (htree) {
  c(
    NP=fitNP(htree),
    BM=fitBM(htree),
    OU1=fitOU1(htree),
    OU2ab=fitOU2ab(htree),
    OU2bc=fitOU2bc(htree),
    OU3=fitOU3(htree)
    )
}
