require(aakmisc)

projname <- "ouchsim"

options(
        stringsAsFactors=FALSE,
        aakmisc.dbname=projname
        )

files <- list.files(pattern=glob2rx("doFits*-*-res.rda"))
cat(length(files),"files to save\n")

dir.create("trash")

startTunnel()

for (file in files) {
  readRDS(file) -> res
  if (!is.data.frame(res)) do.call(rbind,res) -> res
  writeDBTable("fits1",res,append=TRUE)
  cat(sQuote(file),": ",nrow(res)," results saved\n")
  file.rename(from=file,to=file.path("trash",file))
}

stopTunnel()

read.table(pipe("grep jobs doFits*-*.Rout")) -> dat

subset(dat,select=c(2,4,6,8,10,11)) -> dat

names(dat) <- c("jobs","ncpus","chunksize","etime","date","time")
mutate(dat,
       time=as.POSIXct(sprintf("%s %s",date,time),format="%Y-%m-%d %H:%M:%S"),
       date=NULL,
       eff=jobs/ncpus/etime*60
       ) -> dat

png(file=format(Sys.time(),"timing-%Y-%m-%d-%H:%M:%S.png"))
plot(eff~time,data=dat,ylab="jobs/cpu/min")
dev.off()

print(summarize(dat,eff=mean(eff)))

