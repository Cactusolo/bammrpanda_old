require(aakmisc)
require(ouch)
require(foreach)
require(doMPI)
require(pomp)

source("treeFunctions.R")

npaintings <- 40                    # number of regime paintings
npermutes <- 40                     # number of subtrees
waiting.time <- 0.6                 # average time in regime
truth.nregimes <- 3                 # true number of regimes
nparamsets <- 220                   # number of parameter sets overall
ndatasets <- 40                     # number of datasets per painting

cl <- startMPIcluster()
registerDoMPI(cl)

sessionInfo()

l_ply(
      c("ouch","plyr","foreach","doMC","pomp"),
      function (pkg) {
        cat("package",sQuote(pkg),"  \tversion ",
            as.character(packageVersion(pkg)),'\n')
      }
      )

## load the large Anolis phylogeny
bigtree <- readRDS('Anolis_ultrametric_tree.rda')

stopifnot(bigtree@nterm==187)

design <- sobolDesign(
                      lower=c(eta=0.2,phi=0.2,size=9.5),
                      upper=c(eta=5,phi=5,size=50.5),
                      nseq=nparamsets
                      )
design <- mutate(
                 design,
                 paramset=seq_along(size),
                 size=round(size)
                 )

saveRDS(design,file="paramDesign.rda")

png(filename="plots/paramDesign.png",width=8,height=8,units='in',res=150)
pairs(~eta+phi+size,data=design,
      labels=c(expression(eta),expression(phi),'tree size'),
      pch=1)
dev.off()

seeds <- rngSeeds(n=ndatasets,seed=1808677922L)
saveRDS(seeds,file="datasetDesign.rda")

trees <- ldply(
               seq_len(npaintings),
               function (n, tree, seeds) {
                 rngControl(
                            {
                              tree <- insertPoissonEpochs(tree,wait.time=waiting.time)
                              reg <- paintTree(tree,nregimes=truth.nregimes)
                              tree <- mutate(
                                             as(tree,"data.frame"),
                                             nodes=as.character(nodes),
                                             ancestors=as.character(ancestors),
                                             labels=as.character(labels)
                                             )
                              data.frame(
                                         tree,
                                         painting=n,
                                         regimes=reg
                                         )
                            },
                            seed=seeds[n]
                            )
               },
               .parallel=TRUE,
               tree=bigtree,
               seeds=rngSeeds(n=ndatasets,seed=655147273L)
               )

saveRDS(trees,file="treeDesign.rda")

l_ply(
      seq_len(npaintings),
      function (p, trees) {
        tr <- subset(trees,painting==p)
        rownames(tr) <- tr$nodes
        tree <- with(
                     tr,
                     ouchtree(
                              nodes=nodes,
                              ancestors=ancestors,
                              times=times,
                              labels=character(length(nodes))
                              )
                     )
        png(filename=sprintf("plots/treeDesign%02d.png",p),
            width=8,height=16,units='in',res=150)
        plot(tree,regimes=tr["regimes"],lwd,main=sprintf("painting %d",p))
        dev.off()
      },
      .parallel=TRUE,
      trees=trees
      )

perms <- ddply(
               mutate(
                      expand.grid(
                                  painting=seq_len(npaintings),
                                  permutation=seq_len(npermutes)
                                  ),
                      seed=rngSeeds(length(painting),seed=2146845040L)
                      ),
               ~painting+permutation,
               function (d, trees) {
                 rngControl(
                            {
                              tr <- subset(
                                           trees,
                                           painting==d$painting
                                           )
                              perm <- permuteTips(tr$nodes,tr$labels,tr$regimes)
                              data.frame(
                                         painting=d$painting,
                                         permutation=d$permutation,
                                         nodes=perm
                                         )
                            },
                            set.seed(d$seed)
                            )
               },
               .parallel=TRUE,
               trees=trees
               )

saveRDS(perms,file="subtreeDesign.rda")

tree.metrics <- ddply(
                      expand.grid(
                                  painting=seq_len(npaintings),
                                  permutation=seq_len(npermutes),
                                  size=unique(design$size)
                                  ),
                      ~painting+permutation+size,
                      function (d, trees, perms) {
                        tree <- subset(trees,painting==d$painting)
                        perm <- subset(
                                       perms,
                                       permutation==d$permutation &
                                       painting==d$painting
                                       )
                        treeMetrics(
                                    tr=tree,
                                    perm=perm,
                                    size=d$size
                                    )
                      },
                      .parallel=TRUE,
                      trees=trees,
                      perms=perms
                      )

saveRDS(tree.metrics,file="treeMetrics.rda")

png(filename="plots/treeMetrics.png",width=8,height=8,units='in',res=150)
pairs(~size+be+te+imb+nA+nB+nC,data=tree.metrics,
      labels=c('size',expression(J[B]),expression(J[T]),'imbalance',
        expression(n[A]),expression(n[B]),expression(n[C])),
      col=rgb(0,0,0,0.1),pch=16)
dev.off()

closeCluster(cl)
mpi.finalize()
q(save='no')
