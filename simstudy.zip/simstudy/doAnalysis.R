require(aakmisc)
require(dplyr)

options(aakmisc.dbname='ouchsim')
## Clay run this in addition
options(aakmisc.dbname='ouchsim',aakmisc.user='cressler',aakmisc.remotehost='cressler@kinglab.eeb.lsa.umich.edu')

sessionInfo()

startTunnel() -> tun

db <- src_postgres(
                   dbname="ouchsim",
                   host="localhost",
                   user='cressler',# edit out if unneeded
                   port=tun$port
                   )

fits <- tbl(db,"fits")
paramsets <- tbl(db,"paramsets")
metrics <- tbl(db,"metrics")

src_tbls(db)

best <- fits %.% select(
                        id,
                        NP.aic.c,
                        BM.aic.c,
                        OU1.aic.c,
                        OU2ab.aic.c,
                        OU2bc.aic.c,
                        OU3.aic.c) %.%
  mutate(
         best=least(
           NP.aic.c,
           BM.aic.c,
           OU1.aic.c,
           OU2ab.aic.c,
           OU2bc.aic.c,
           OU3.aic.c
           )
         ) %.% compute() %.%
  mutate(
         ou3=best==OU3.aic.c,
         ou2ab=best==OU2ab.aic.c,
         ou2bc=best==OU2bc.aic.c,
         ou1=best==OU1.aic.c,
         bm=best==BM.aic.c,
         np=best==NP.aic.c
         ) %.%
  select(id,ou3,ou2ab,ou2bc,ou1,bm,np)

fits <- left_join(fits,best,by='id')

power <- fits %.%
  group_by(painting,permutation,paramset) %.%
  summarise(
            ou3=sum(as.integer(ou3)),
            ou2ab=sum(as.integer(ou2ab)),
            ou2bc=sum(as.integer(ou2bc)),
            ou1=sum(as.integer(ou1)),
            bm=sum(as.integer(bm)),
            np=sum(as.integer(np))
            ) %.%
  left_join(paramsets,by='paramset') %.%
  left_join(metrics,by=c('painting','permutation','size')) %.%
  mutate(
         snr=sqrt(eta)*phi,
         freq=(ou3+0.5)/(ou3+ou2ab+ou2bc+ou1+bm+np+1)
         ) %.%
  collect()

error <- fits %.%
  filter(ou3) %.%
  left_join(paramsets,by='paramset') %.%
  mutate(
         eta.err=OU3.est.eta-eta,
         phi.err=OU3.est.phi-phi,
         theta.A.err=OU3.est.theta.A-(-1),
         theta.B.err=OU3.est.theta.B-(0),
         theta.C.err=OU3.est.theta.C-(1)
         ) %.%
  group_by(painting,permutation,paramset) %.%
  summarise(
            n=n(),
            eta.bias=mean(eta.err),
            phi.bias=mean(phi.err),
            theta.A.bias=mean(theta.A.err),
            theta.B.bias=mean(theta.B.err),
            theta.C.bias=mean(theta.C.err),
            eta.sd=sd(eta.err),
            phi.sd=sd(phi.err),
            theta.A.sd=sd(theta.A.err),
            theta.B.sd=sd(theta.B.err),
            theta.C.sd=sd(theta.C.err)
            ) %.%
  left_join(paramsets,by='paramset') %.%
  left_join(metrics,by=c('painting','permutation','size')) %.%
  mutate(
         eta.rmse=sqrt(eta.bias^2+eta.sd^2),
         phi.rmse=sqrt(phi.bias^2+phi.sd^2),
         theta.A.rmse=sqrt(theta.A.bias^2+theta.A.sd^2),
         theta.B.rmse=sqrt(theta.B.bias^2+theta.B.sd^2),
         theta.C.rmse=sqrt(theta.C.bias^2+theta.C.sd^2)
         ) %.%
  collect()

power <- as.data.frame(power)
error <- as.data.frame(error)

dbWriteTable(db$con,"power",power,overwrite=TRUE,row.names=FALSE)
dbWriteTable(db$con,"error",error,overwrite=TRUE,row.names=FALSE)

save(power,error,file="results.rda",compress='xz')

## If you are not rebuilding error and power, run these instead
power <- getQuery("select * from power",port=tun$port)
error <- getQuery("select * from error",port=tun$port)

require(mgcv)

logit <- function (p) log(p/(1-p))
expit <- function (x) 1/(1+exp(-x))

## GAM regression on power
fit1a <- gam(logit(freq)~s(eta,phi,size),data=power)
fit1b <- gam(logit(freq)~be+s(eta,phi,size),data=power)
fit1c <- gam(logit(freq)~be+imb+s(eta,phi,size),data=power)
fit1d <- gam(logit(freq)~be+te+imb+s(eta,phi,size),data=power)
fit1e <- gam(logit(freq)~s(be)+s(te)+s(imb)+s(eta,phi,size),data=power)
fit1f <- gam(logit(freq)~s(be,te)+s(imb)+s(eta,phi,size),data=power)
anova(fit1f,fit1e,fit1d,fit1c,fit1b,fit1a)
c(summary(fit1f)$r.sq, summary(fit1e)$r.sq, summary(fit1d)$r.sq, summary(fit1c)$r.sq, summary(fit1b)$r.sq, summary(fit1a)$r.sq)
## the best-fitting model is fit1f
coef(fit1f)[c("be","te","imb")]*sapply(power[c("be","te","imb")],sd)
summary(fit1f)

## GAM regression on relative RMSE in eta estimate
fit2a <- gam(log10(eta.rmse/eta)~s(eta,phi,size),data=error)
fit2b <- gam(log10(eta.rmse/eta)~be+s(eta,phi,size),data=error)
fit2c <- gam(log10(eta.rmse/eta)~be+imb+s(eta,phi,size),data=error)
fit2d <- gam(log10(eta.rmse/eta)~be+te+imb+s(eta,phi,size),data=error)
fit2e <- gam(log10(eta.rmse/eta)~s(be)+s(te)+s(imb)+s(eta,phi,size),data=error)
fit2f <- gam(log10(eta.rmse/eta)~s(be,te)+s(imb)+s(eta,phi,size),data=error)
## absolute RMSE
fit2g <- gam(log10(eta.rmse)~s(be,te)+s(imb)+s(eta,phi,size),data=error)

anova(fit2f,fit2e,fit2d,fit2c,fit2b,fit2a)
c(summary(fit2e)$r.sq, summary(fit2f)$r.sq, summary(fit2d)$r.sq, summary(fit2c)$r.sq, summary(fit2b)$r.sq, summary(fit2a)$r.sq)
## the best-fitting model is fit2f
coef(fit2f)[c("be","te","imb")]*sapply(error[c("be","te","imb")],sd)
summary(fit2f)

## GAM regression on relative RMSE in phi estimate
fit3a <- gam(log10(phi.rmse/phi)~s(eta,phi,size),data=error)
fit3b <- gam(log10(phi.rmse/phi)~be+s(eta,phi,size),data=error)
fit3c <- gam(log10(phi.rmse/phi)~be+imb+s(eta,phi,size),data=error)
fit3d <- gam(log10(phi.rmse/phi)~be+te+imb+s(eta,phi,size),data=error)
fit3e <- gam(log10(phi.rmse/phi)~s(be)+s(te)+s(imb)+s(eta,phi,size),data=error)
fit3f <- gam(log10(phi.rmse/phi)~s(be,te)+s(imb)+s(eta,phi,size),data=error)
anova(fit3f,fit3e,fit3d,fit3c,fit3b,fit3a)
c(summary(fit3f)$r.sq, summary(fit3e)$r.sq, summary(fit3d)$r.sq, summary(fit3c)$r.sq, summary(fit3b)$r.sq, summary(fit3a)$r.sq)
## absolute RMSE
fit3g <- gam(log10(phi.rmse)~s(be,te)+s(imb)+s(eta,phi,size),data=error)

## the best-fitting model is fit3f
coef(fit3f)[c("be","te","imb")]*sapply(error[c("be","te","imb")],sd)
summary(fit3f)

## fit4a <- gam(log10(snr.rmse/snr)~s(eta,phi,size),data=error)
## fit4b <- gam(log10(snr.rmse/snr)~be+te+imb+s(eta,phi,size),data=error)
## anova(fit4a,fit4b)
## coef(fit4b)[c("be","te","imb")]*sapply(error[c("be","te","imb")],sd)
## summary(fit4b)
## mutate(eta.phi.pred,log10.snr.re=predict(fit4b,newdata=eta.phi.pred)) -> eta.phi.pred

## GAM regression on RMSE in theta estimates
fit5a <- gam(log10(theta.A.rmse)~s(eta,phi,size),data=error)
fit5b <- gam(log10(theta.A.rmse)~be+s(eta,phi,size),data=error)
fit5c <- gam(log10(theta.A.rmse)~be+imb+s(eta,phi,size),data=error)
fit5d <- gam(log10(theta.A.rmse)~be+te+imb+s(eta,phi,size),data=error)
fit5e <- gam(log10(theta.A.rmse)~s(be)+s(te)+s(imb)+s(eta,phi,size),data=error)
fit5f <- gam(log10(theta.A.rmse)~s(be,te)+s(imb)+s(eta,phi,size),data=error)
anova(fit5f,fit5e,fit5d,fit5c,fit5b,fit5a)
round(c(summary(fit5f)$r.sq, summary(fit5e)$r.sq, summary(fit5d)$r.sq, summary(fit5c)$r.sq, summary(fit5b)$r.sq, summary(fit5a)$r.sq),5)
## the best-fitting model is fit5f
coef(fit5f)[c("be","te","imb")]*sapply(error[c("be","te","imb")],sd)
summary(fit5f)

fit6a <- gam(log10(theta.B.rmse)~s(eta,phi,size),data=error)
fit6b <- gam(log10(theta.B.rmse)~be+s(eta,phi,size),data=error)
fit6c <- gam(log10(theta.B.rmse)~be+imb+s(eta,phi,size),data=error)
fit6d <- gam(log10(theta.B.rmse)~be+te+imb+s(eta,phi,size),data=error)
fit6e <- gam(log10(theta.B.rmse)~s(be)+s(te)+s(imb)+s(eta,phi,size),data=error)
fit6f <- gam(log10(theta.B.rmse)~s(be,te)+s(imb)+s(eta,phi,size),data=error)
anova(fit6f,fit6e,fit6d,fit6c,fit6b,fit6a)
round(c(summary(fit6f)$r.sq, summary(fit6e)$r.sq, summary(fit6d)$r.sq, summary(fit6c)$r.sq, summary(fit6b)$r.sq, summary(fit6a)$r.sq),5)
## the best-fitting model is fit6f
coef(fit6f)[c("be","te","imb")]*sapply(error[c("be","te","imb")],sd)
summary(fit6f)

fit7a <- gam(log10(theta.C.rmse)~s(eta,phi,size),data=error)
fit7b <- gam(log10(theta.C.rmse)~be+s(eta,phi,size),data=error)
fit7c <- gam(log10(theta.C.rmse)~be+imb+s(eta,phi,size),data=error)
fit7d <- gam(log10(theta.C.rmse)~be+te+imb+s(eta,phi,size),data=error)
fit7e <- gam(log10(theta.C.rmse)~s(be)+s(te)+s(imb)+s(eta,phi,size),data=error)
fit7f <- gam(log10(theta.C.rmse)~s(be,te)+s(eta,phi,size),data=error)
anova(fit7f,fit7e,fit7d,fit7c,fit7b,fit7a)
round(c(summary(fit7f)$r.sq, summary(fit7e)$r.sq, summary(fit7d)$r.sq, summary(fit7c)$r.sq, summary(fit7b)$r.sq, summary(fit7a)$r.sq),5)
## the best-fitting model is fit7F
coef(fit7f)[c("be","te","imb")]*sapply(error[c("be","te","imb")],sd)
summary(fit7f)

## Repeat the GAM regressions, using SNR as a predictor instead of eta and phi
mutate(error, snr=sqrt(eta)*phi) -> error
fit8 <- gam(logit(freq)~s(be,te)+s(imb)+s(snr,size),data=power)
fit9 <- gam(log10(eta.rmse)~s(be,te)+s(imb)+s(snr,size),data=error)
fit10 <- gam(log10(phi.rmse)~s(be,te)+s(imb)+s(snr,size),data=error)
fit11 <- gam(log10(theta.A.rmse)~s(be,te)+s(imb)+s(snr,size),data=error)
fit12 <- gam(log10(theta.B.rmse)~s(be,te)+s(imb)+s(snr,size),data=error)
fit13 <- gam(log10(theta.C.rmse)~s(be,te)+s(imb)+s(snr,size),data=error)

## Save the summaries for each GAM fit (cannot save the GAM object themselves, they are much too large) and the anova comparing the gams
gam.summaries <- list(fit1a=summary(fit1a), fit1b=summary(fit1b), fit1c=summary(fit1c), fit1d=summary(fit1d),
                      fit1e=summary(fit1e), fit1f=summary(fit1f),
                      fit2a=summary(fit2a), fit2b=summary(fit2b), fit2c=summary(fit2c), fit2d=summary(fit2d),
                      fit2e=summary(fit2e), fit2f=summary(fit2f),
                      fit3a=summary(fit3a), fit3b=summary(fit3b), fit3c=summary(fit3c), fit3d=summary(fit3d),
                      fit3e=summary(fit3e), fit3f=summary(fit3f),
                      fit5a=summary(fit5a), fit5b=summary(fit5b), fit5c=summary(fit5c), fit5d=summary(fit5d),
                      fit3e=summary(fit5e), fit3f=summary(fit5f),
                      fit6a=summary(fit6a), fit6b=summary(fit6b), fit6c=summary(fit6c), fit6d=summary(fit6d),
                      fit3e=summary(fit6e), fit3f=summary(fit6f),
                      fit7a=summary(fit7a), fit7b=summary(fit7b), fit7c=summary(fit7c), fit7d=summary(fit7d),
                      fit3e=summary(fit7e), fit3f=summary(fit7f),
                      fit8=summary(fit8), fit9=summary(fit9), fit10=summary(fit10), fit11=summary(fit11),
                      fit12=summary(fit12), fit13=summary(fit13))
gam.anovas <- list(power=anova(fit1f,fit1e,fit1d,fit1c,fit1b,fit1a),
                   log10.eta.re=anova(fit2f,fit2e,fit2d,fit2c,fit2b,fit2a),
                   log10.phi.re=anova(fit3f,fit3e,fit3d,fit3c,fit3b,fit3a),
                   log10.theta.A.rmse=anova(fit5f,fit5e,fit5d,fit5c,fit5b,fit5a),
                   log10.theta.B.rmse=anova(fit6f,fit6e,fit6d,fit6c,fit6b,fit6a),
                   log10.theta.C.rmse=anova(fit7f,fit7e,fit7d,fit7c,fit7b,fit7a))
save(gam.summaries, file='gam_summaries.rda', compress='xz')
save(gam.anovas, file='gam_anovas.rda')

## GAM predictions
eta.phi.pred <- expand.grid(
                            eta=seq(0.2,5,by=0.02),
                            phi=seq(0.2,5,by=0.02),
                            size=seq(10,50,by=20),
                            be=c(0.6,0.8,1),
                            te=c(0.8,1),
                            imb=c(-0.5,0,1,2)
                            )

## Predict power based on the GAM
mutate(eta.phi.pred,
       freq=as.numeric(expit(predict(fit1f,newdata=eta.phi.pred)))
       ) -> eta.phi.pred
## Predict eta, phi, absolute RMSE based on the GAMs
mutate(eta.phi.pred,
       log10.eta.abs=as.numeric(predict(fit2g,newdata=eta.phi.pred))
       ) -> eta.phi.pred
mutate(eta.phi.pred,
       log10.phi.abs=as.numeric(predict(fit3g,newdata=eta.phi.pred))
       ) -> eta.phi.pred
## Predict eta, phi, relative RMSE based on the GAMs
mutate(eta.phi.pred,
       log10.eta.re=as.numeric(predict(fit2f,newdata=eta.phi.pred))
       ) -> eta.phi.pred
mutate(eta.phi.pred,
       log10.phi.re=as.numeric(predict(fit3f,newdata=eta.phi.pred))
       ) -> eta.phi.pred
## Predict theta RMSE based on the GAMs
mutate(eta.phi.pred,
       log10.theta.A.rmse=as.numeric(predict(fit5f,newdata=eta.phi.pred))
       ) -> eta.phi.pred
mutate(eta.phi.pred,
       log10.theta.B.rmse=as.numeric(predict(fit6f,newdata=eta.phi.pred))
       ) -> eta.phi.pred
mutate(eta.phi.pred,
       log10.theta.C.rmse=as.numeric(predict(fit7f,newdata=eta.phi.pred))
       ) -> eta.phi.pred

save(eta.phi.pred, file='eta_phi_pred.rda')

dbWriteTable(db$con,"etaphipred",eta.phi.pred,overwrite=TRUE,row.names=FALSE)

## GAM predictions
snr.pred <- expand.grid(
                        snr=seq(0.1,10,by=0.02),
                        size=seq(10,50,by=0.5),
                        be=c(0.6,0.8,1),
                        te=c(0.6,0.8,1),
                        imb=c(-0.5,0,1,2)
                        )
## Predict power based on the GAM
mutate(snr.pred,
       freq=as.numeric(expit(predict(fit8,newdata=snr.pred)))
       ) -> snr.pred
## Predict eta, phi, relative RMSE based on the GAMs
mutate(snr.pred,
       log10.eta.re=as.numeric(predict(fit9,newdata=snr.pred))
       ) -> snr.pred
mutate(snr.pred,
       log10.phi.re=as.numeric(predict(fit10,newdata=snr.pred))
       ) -> snr.pred
## Predict theta RMSE based on the GAMs
mutate(snr.pred,
       log10.theta.A.rmse=as.numeric(predict(fit11,newdata=snr.pred))
       ) -> snr.pred
mutate(snr.pred,
       log10.theta.B.rmse=as.numeric(predict(fit12,newdata=snr.pred))
       ) -> snr.pred
mutate(snr.pred,
       log10.theta.C.rmse=as.numeric(predict(fit13,newdata=snr.pred))
       ) -> snr.pred

dbWriteTable(db$con,"snrpred",snr.pred,overwrite=TRUE,row.names=FALSE)

save(snr.pred, file='snr_pred.rda')

stopTunnel(tun)

## One extra prediction: phi for no.tips = 15, 20, 25
eta.phi.pred.2 <- expand.grid(
                            eta=seq(0.2,5,by=0.02),
                            phi=seq(0.2,5,by=0.02),
                            size=c(12,15,20,25,28),
                            be=c(0.6,0.8,1),
                            te=c(1),
                            imb=c(-0.5)
                            )
mutate(eta.phi.pred.2,
       log10.phi.re=as.numeric(predict(fit3f,newdata=eta.phi.pred.2))
       ) -> eta.phi.pred.2
save(eta.phi.pred.2, file='eta_phi_pred_2.rda')

## Power and error do not contain exactly the same data, because parameter estimates were only recorded if at least one phenotypic dataset supported the OU(3) model. This code figures out the reordering of rows necessary to make power and error have exactly the same order.
if(!file.exists('power_rows_in_error.rda')) {
  i <- j <- 1
  which.rows <- vector(length=nrow(error))
  while(i < (nrow(error)+1)) {
    print(c(i,j))
    ind <- which(power$painting[max(c(1,j-50)):min(c(j+50,nrow(power)))]==error$painting[i] &
                 power$permutation[max(c(1,j-50)):min(c(j+50,nrow(power)))]==error$permutation[i] &
                 power$size[max(c(1,j-50)):min(c(j+50,nrow(power)))]==error$size[i] &
                 power$paramset[max(c(1,j-50)):min(c(j+50,nrow(power)))]==error$paramset[i])
    if (length(ind) > 0) {
      j <- (max(c(1,j-50)):min(c(j+50,nrow(power))))[ind]
      which.rows[i] <- j
    }
    else {
      j <- which(power$painting==error$painting[i] &
                 power$permutation==error$permutation[i] &
                 power$size==error$size[i] &
                 power$paramset==error$paramset[i])
      which.rows[i] <- j
    }
    i <- i+1
  }
  save(which.rows, file='power_rows_in_error.rda')
}

## GAMs to calculate the dependence of RMSE(theta) on the state at the root
x <- readRDS('treeDesign.rda')
library(mgcv)
thA.rootA <- gam(log10(theta.A.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='A')))
thB.rootA <- gam(log10(theta.B.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='A')))
thC.rootA <- gam(log10(theta.C.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='A')))

thA.rootB <- gam(log10(theta.A.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='B')))
thB.rootB <- gam(log10(theta.B.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='B')))
thC.rootB <- gam(log10(theta.C.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='B')))

thA.rootC <- gam(log10(theta.A.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='C')))
thB.rootC <- gam(log10(theta.B.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='C')))
thC.rootC <- gam(log10(theta.C.rmse)~s(be,te)+s(imb)+s(eta,phi,size), data=subset(error, painting%in%which(x[x$nodes=='1','regimes']=='C')))

## new prediction dataframe varying only eta and phi
theta.pred <- expand.grid(
                          eta=seq(0.2,5,by=0.02),
                          phi=seq(0.2,5,by=0.02),
                          size=c(30), be=c(1), te=c(1), imb=c(-0.5))
mutate(theta.pred, thA.rootA=predict(thA.rootA, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thB.rootA=predict(thB.rootA, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thC.rootA=predict(thC.rootA, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thA.rootB=predict(thA.rootB, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thB.rootB=predict(thB.rootB, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thC.rootB=predict(thC.rootB, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thA.rootC=predict(thA.rootC, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thB.rootC=predict(thB.rootC, newdata=theta.pred)) -> theta.pred
mutate(theta.pred, thC.rootC=predict(thC.rootC, newdata=theta.pred)) -> theta.pred
z <- reshape(theta.pred, varying=7:15, direction='long')
rownames(z) <- 1:nrow(z); z <- z[,-ncol(z)]
names(z)[7:10] <- c('root', 'theta.A', 'theta.B','theta.C')
z2 <- reshape(z, varying=8:10, direction='long')
rownames(z2) <- 1:nrow(z2); z <- z[,-ncol(z)]
names(z2)[8] <- c('optima')
z2 <- transform(z2, root=factor(root, levels=c('rootA','rootB','rootC'), labels=c('Root==A', 'Root==B', 'Root==C')))
z2 <- transform(z2, optima=factor(optima, levels=c('A','B','C'), labels=c('RMSE(theta[A])','RMSE(theta[B])','RMSE(theta[C])')))
saveRDS(z2, file='rmse_theta_by_root_gam.rda')

