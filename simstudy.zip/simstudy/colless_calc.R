require(aakmisc)
require(ouch)
require(foreach)
require(doMPI)
require(pomp)

source("treeFunctions.R")

npaintings <- 40                    # number of regime paintings
npermutes <- 40                     # number of subtrees
waiting.time <- 0.6                 # average time in regime
truth.nregimes <- 3                 # true number of regimes
nparamsets <- 220                   # number of parameter sets overall
ndatasets <- 40                     # number of datasets per painting

bigtree <- readRDS('Anolis_ultrametric_tree.rda')
design <- readRDS('datasetDesign.rda')
trees <- readRDS('treeDesign.rda')
perms <- readRDS('subtreeDesign.rda')

## compute the colless index - painting doesn't matter
stf <- expand.grid(
                   painting=1,
                   permutation=seq_len(npermutes),
                   size=unique(design$size)
                   )
d <- stf[1230,]
tr <- subset(trees,painting==d$painting)
perm <- subset(
    perms,
    permutation==d$permutation &
    painting==d$painting
    )
size <- d$size

colless <- ddply(
    expand.grid(
        permutation=seq_len(npermutes),
        size=unique(design$size)
        ),
    ~permutation+size,
    function(d, trees, perms) {
        tree <- subset(trees, painting==1)
        perm <- subset(
            perms,
            permutation==d$permutation &
            painting==1
            )
        calcColless(tr=tree, perm=perm, size=d$size)
    },
    trees=trees,
    perms=perms
    )
saveRDS(colless, file='colless_indices.rda')

gamma <- 0.5772156649
ecoll <- sapply(10:32, function(x) (x*log(x)+(gamma-1-log(2))*x)/((x-1)*(x-2)/2))

png(file='Colless_index.png', res=300, height=5, width=5, units='in')
plot(colless[,2:3], xlim=c(10,32), xlab='Tree size', ylab=expression('Colless index'~~italic(I[c])))
lines(10:32, ecoll, lty=2)
dev.off()


## calculate the Colless index (uncorrected) for any tree that has no polytomies
calcColless <- function(tr, perm, size) {
    tree <- with(tr,ouchtree(nodes,ancestors,times,labels))
    tips <- head(perm$nodes,size)
    tree <- subtree(tree,tips)
    ## lineages of the tip species
    tiplins <- lapply(tree@term, function(x) tree@nodes[tree@lineages[[x]]])

    ## Find all the true internal nodes (because of our method of creating the trees, there are nodes that have only a single ancestors - these nodes are either regime shift nodes or internal nodes on the full phylogeny that only had a single ancestor in this subtree).
    intnodes <- as.numeric(sapply(tree@nodes, function(x) sum(tree@ancestors==x,na.rm=T)))

    ## if there are polytomies, skip this tree and move on
    if (any(intnodes > 2))
        Ic <- NA
    else { ## keep only the binary nodes
        intnodes <- which(intnodes==2)
        NR <- vector()
        NL <- vector()
        ## count the number of tips descended from the right and left branches for each internal node, ignoring switch nodes and ghost nodes
        for (i in intnodes) {
            R <- which(tree@ancestors==tree@nodes[i])[1]
            L <- which(tree@ancestors==tree@nodes[i])[2]
            ## number of tip lineages containing the R node
            nr <- sum(unlist(lapply(tiplins, function(x) any(x==tree@nodes[R]))))
            nl <- sum(unlist(lapply(tiplins, function(x) any(x==tree@nodes[L]))))
            NR <- c(NR,nr)
            NL <- c(NL,nl)
        }
        Ic <- sum(abs(NR-NL))/((size-1)*(size-2)/2)
    }
    return(Ic)
}

