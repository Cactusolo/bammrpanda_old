require(aakmisc)

options(aakmisc.dbname='ouchsim')

startTunnel()
f <- getQuery("select * from fits1")
f1 <- getQuery(paste("select * from fits where id <=",max(f$id)))
stopTunnel()

f1 <- subset(f1,id%in%sort(f$id))
arrange(f,id) -> f
arrange(f1,id) -> f1

stopifnot(all.equal(f,f1))
