require(aakmisc)

projname <- "ouchsim"

options(
        stringsAsFactors=FALSE,
        aakmisc.dbname=projname
        )

readRDS("treeDesign.rda") -> trees
readRDS("subtreeDesign.rda") -> perms
readRDS("paramDesign.rda") -> paramsets
readRDS("treeMetrics.rda") -> metrics

startTunnel() -> tun
writeDBTable("trees",trees,overwrite=T,port=tun$port)
writeDBTable("subtrees",perms,overwrite=T,port=tun$port)
writeDBTable("paramsets",paramsets,overwrite=T,port=tun$port)
writeDBTable("metrics",metrics,overwrite=T,port=tun$port)
stopTunnel(tun)
